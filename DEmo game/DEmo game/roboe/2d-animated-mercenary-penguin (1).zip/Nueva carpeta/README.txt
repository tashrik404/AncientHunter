
Thank you for acquire this asset.

All content in this folder has been created by Israel Maraver Talavera 
Contact address: isramaraver@gmail.com


									----------------------------------------------


Content list:

- DragonBones Animations

	This folder contains the original dragonbones files where the animations were made.

- Animation PNG secuence:

	This folder contains all the animations divided into a sequence of images in PNG format.

- DragonBones JSON 5.5 

	This folder contains the JSON file and the texture atlas. It can be used to directly import the bone animation to the game engine.


- Sprite Sheets

	This folder contains the sprites sheets.


- Image Resources

	This folder contains the PSD file with the original images separated into layers.
	And a subfolder with the PNG exported images.
										

									----------------------------------------------


These Assets were created with Krita and DragonBones Pro, both programs are free so they are accessible to anyone if they want to carry out any modification.

The JSON file was exported in DB 5.5 format which is supported by most engines.
Take a look at this link shows a table with the supported game engines:

http://blog.dragonbones.com/en/engine-support

You can use DragonBones to export the animations in any other format.

For unity users, there is a plugin. With it, you can using the DragonBones data files in Unity. The plugin is an unitypackage file.
You can get it through this link:

https://github.com/DragonBones/DragonBonesCSharp/releases

And here is the video guide about how to use it:

https://www.youtube.com/watch?v=O2fTwwisInc


If you have any questions or problems please do not hesitate to contact me.

